<?php
require "dbconnection.php";

class UserInfo
{
	public $id, $fname, $lname, $dept, $type, $sdate, $edate, $reason ;

	public function __construct($id, $fname, $lname, $dept, $type, $sdate, $edate, $reason)
	{
		$this->id = $id;
		$this->fname = $fname;
		$this->lname = $lname;
		$this->dept = $dept ;
		$this->type=$type;
		$this->sdate = $sdate;
		$this->edate = $edate;
		$this->reason = $reason;
	}

	public function insertDatabase($con)
	{
		$query = "INSERT INTO leavetable(`f_id`, `sdate`, `edate`, `ltype`, `reason`) VALUES";
		$query = $query . "('" . $this->id . "','" . $this->sdate . "','" . $this->edate . "','" . $this->type . "','" . $this->reason . "');";
		$result = mysqli_query($con, $query);
		if ($result) {
			echo "<br><br>Leave Apllication Successfully Submitted. You will get response very soon!!<br><br>";
		} else {
			echo "<br><br>NO!!<br><br>";
		}

	}
}

if (isset($_POST['submit'])) {
	$user = new UserInfo($_POST['id'], $_POST['fname'], $_POST['lname'], $_POST['dept'], $_POST['type'], $_POST['sdate'], $_POST['edate'], $_POST['reason']);
	$user->insertDatabase($con);
}

?>