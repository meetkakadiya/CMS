<?php
$host="localhost";
$user="root";
$pass="";
$db="cms";
$con = mysqli_connect($host,$user,$pass,$db);
/**if($con)
{
	echo "Yes";
}
else
{
	echo "No";
}*/