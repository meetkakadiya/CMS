<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from www.urbanui.com/gleam/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 16 Jul 2018 22:36:08 GMT -->
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Staff Admin</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="images/favicon.png" />
</head>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
        <a class="navbar-brand brand-logo" href="index.html"> SPEC</a>
        <a class="navbar-brand brand-logo-mini" href="index.html">SPEC</a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center">
        <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
          <span class="mdi mdi-menu"></span>
        </button>
        <span class="d-none d-md-inline">Staff Dashboard </span>
        <ul class="navbar-nav navbar-nav-right">
          <li class="nav-item nav-profile">
            <a class="nav-link">
              <div class="nav-profile-text">
                <p class="mb-0" id="pro name">Pro. Mahesh Shah</p>
              </div>
              <div class="nav-profile-img">
                <img src="images/faces/face16.jpg" alt="image">
              </div>
            </a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link count-indicator dropdown-toggle" id="messageDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
              <i class="mdi mdi-message-text-outline"></i>
              <span class="count-symbol"></span>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="messageDropdown">
              <h6 class="p-3 mb-0" id="messages">Messages</h6>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                    <img src="images/faces/face4.jpg" alt="image" class="profile-pic">
                </div>
                <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                  <h6 class="preview-subject ellipsis mb-1 font-weight-normal">Jay submmited his assignments</h6>
                  <p class="text-gray mb-0">
                    1 Minutes ago
                  </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                    <img src="images/faces/face2.jpg" alt="image" class="profile-pic">
                </div>
                <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                  <h6 class="preview-subject ellipsis mb-1 font-weight-normal">Pro. Janvi send her report</h6>
                  <p class="text-gray mb-0">
                    15 Minutes ago
                  </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                    <img src="images/faces/face16.jpg" alt="image" class="profile-pic">
                </div>
                <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                  <h6 class="preview-subject ellipsis mb-1 font-weight-normal">Profile picture updated</h6>
                  <p class="text-gray mb-0">
                    18 Minutes ago
                  </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <h6 class="p-3 mb-0 text-center">4 new messages</h6>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#" data-toggle="dropdown">
              <i class="mdi mdi-bell-outline"></i>
              <span class="count-symbol bg-info"></span>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="notificationDropdown">
              <h6 class="p-3 mb-0">Notifications</h6>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-success">
                    <i class="mdi mdi-calendar"></i>
                  </div>
                </div>
                <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                  <h6 class="preview-subject font-weight-normal mb-1">Event today</h6>
                  <p class="text-gray ellipsis mb-0">
                    Just a reminder that you have an event today
                  </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-warning">
                    <i class="mdi mdi-settings"></i>
                  </div>
                </div>
                <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                  <h6 class="preview-subject font-weight-normal mb-1">Settings</h6>
                  <p class="text-gray ellipsis mb-0">
                    Update dashboard
                  </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-info">
                    <i class="mdi mdi-link-variant"></i>
                  </div>
                </div>
                <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                  <h6 class="preview-subject font-weight-normal mb-1">Launch Admin</h6>
                  <p class="text-gray ellipsis mb-0">
                    New admin wow!
                  </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <h6 class="p-3 mb-0 text-center">See all notifications</h6>
            </div>
          </li>
          <li class="nav-item nav-logout d-none d-lg-block">
            <a class="nav-link" href="#">
              Logout
              <i class="mdi mdi-power"></i>
            </a>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="mdi mdi-menu"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_settings-panel.html -->
<!--
      <div id="settings-trigger"><i class="mdi mdi-format-color-fill"></i></div>
      <div id="theme-settings" class="settings-panel">
        <i class="settings-close mdi mdi-close"></i>
        <p class="settings-heading">SIDEBAR SKINS</p>
        <div class="sidebar-bg-options selected" id="sidebar-default-theme"><div class="img-ss rounded-circle bg-light border mr-3"></div>Default</div>
        <div class="sidebar-bg-options" id="sidebar-dark-theme"><div class="img-ss rounded-circle bg-dark border mr-3"></div>Dark</div>
        <p class="settings-heading mt-2">HEADER SKINS</p>
        <div class="color-tiles mx-0 px-4">
          <div class="tiles primary"></div>
          <div class="tiles success"></div>
          <div class="tiles warning"></div>
          <div class="tiles danger"></div>
          <div class="tiles info"></div>
          <div class="tiles dark"></div>
          <div class="tiles default light"></div>
        </div>
      </div>
-->
      <!-- partial -->
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item nav-profile">
            <span class="nav-link">
              <img src="images/faces/face16.jpg" alt="image"/>
              <span class="nav-profile-text">Pro. Mahesh Shah</span>
<!--              <span class="badge badge-pill badge-gradient-danger"> 1</span>-->
            </span>
          </li>
          <li class="nav-item d-none">
            <a class="nav-link" href="index.html">
              <i class="mdi mdi-home-outline menu-icon"></i>              
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
            <li class="nav-item d-none">
            <a class="nav-link" data-toggle="collapse" href="#forms" aria-expanded="false" aria-controls="forms">
              <i class="mdi mdi mdi-file-outline menu-icon"></i>              
              <span class="menu-title">Forms</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="forms">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="pages/forms/basic_elements.html">Leave Forms</a></li>
<!--
                <li class="nav-item"> <a class="nav-link" href="pages/forms/advanced_elements.html">Advanced Forms</a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/forms/validation.html">Validation</a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/forms/wizard.html">Wizard</a></li>
-->
              </ul>
            </div>
          </li>
          <li class="nav-item d-none">
            <a class="nav-link" href="pages/ui-features/notifications.html">
              <i class="mdi mdi-backup-restore menu-icon"></i>              
              <span class="menu-title">Notifications</span>
              <span class="badge badge-gradient-success badge-pill">9</span>
            </a>
            </li>
            <li class="nav-item" data-toggle="modal" data-target="#book-request">
            <a class="nav-link" href="#">
              <i class="mdi mdi-file-document-box menu-icon"></i>              
              <span class="menu-title">Book Request</span>
            </a>
          </li>
          <li class="nav-item" data-toggle="modal" data-target="#leave-form">
            <a class="nav-link" href="#">
              <i class="mdi mdi-file menu-icon"></i>              
              <span class="menu-title">Leave Form</span>
            </a>
          </li>
           <li class="nav-item" data-toggle="modal" data-target="#Material-Upload">
            <a class="nav-link" href="#">
              <i class="mdi mdi-file-outline menu-icon"></i>              
              <span class="menu-title">Material Upload</span>
            </a>
          </li>
            <li class="nav-item" data-toggle="modal" data-target="#Assignment-Upload">
            <a class="nav-link" href="#">
              <i class="mdi mdi-code-brackets menu-icon"></i>              
              <span class="menu-title">Assignment Upload</span>
            </a>
          </li>
            
          <li class="nav-item d-none">
            <a class="nav-link" data-toggle="collapse" href="#charts" aria-expanded="false" aria-controls="charts">
              <i class="mdi mdi-chart-line menu-icon"></i>              
              <span class="menu-title">Charts</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="charts">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="pages/charts/chartjs.html">ChartJs</a></li>
<!--
                <li class="nav-item"> <a class="nav-link" href="pages/charts/morris.html">Morris</a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/charts/flot-chart.html">Flot</a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/charts/google-charts.html">Google charts</a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/charts/sparkline.html">Sparkline js</a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/charts/c3.html">C3 charts</a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/charts/chartist.html">Chartist</a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/charts/justGage.html">JustGage</a></li>
-->
              </ul>
              </div>
          </li>
          <li class="nav-item d-none">
            <a class="nav-link" data-toggle="collapse" href="#tables" aria-expanded="false" aria-controls="tables">
              <i class="mdi mdi-table menu-icon"></i>              
              <span class="menu-title">Tables</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="tables">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="pages/tables/basic-table.html">Time table</a></li>
<!--
                <li class="nav-item"> <a class="nav-link" href="pages/tables/data-table.html">Data table</a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/tables/js-grid.html">Js-grid</a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/tables/sortable-table.html">Sortable table</a></li>
-->
              </ul>
              </div>
          <li class="nav-item">
            <a class="nav-link" href="pages/apps/email.html">
              <i class="mdi mdi-email-outline menu-icon"></i>              
              <span class="menu-title">E-mail</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="pages/apps/calendar.html">
              <i class="mdi mdi-calendar-today menu-icon"></i>              
              <span class="menu-title">Calendar</span>
            </a>
          </li>
          <li class="nav-item d-none">
            <a class="nav-link" href="#">
              <i class="mdi mdi-image-filter menu-icon"></i>              
              <span class="menu-title">Gallery</span>
              <span class="badge badge-gradient-warning badge-pill">9</span>
            </a>
          </li>
          <li class="nav-item d-none">
            <a class="nav-link" href="pages/documentation.html">
              <i class="mdi mdi-file-document-box menu-icon"></i>              
              <span class="menu-title">Documentation</span>
            </a>
          </li>
          <li class="nav-item sidebar-actions">
            <a class="nav-link" href="#">
              <i class="mdi mdi-circle-outline menu-icon text-danger"></i>
              Settings
            </a>
            <a class="nav-link" href="#">
              <i class="mdi mdi-circle-outline menu-icon text-danger"></i>
              Contact Support
            </a>
            <span class="nav-link">
              &copy; 2018 SPEC
            </span>
          </li>
        </ul>
      </nav>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="page-header">
            <h3 class="page-title">
              Dashboard
<!--              <span class="ml-2 h6 font-weight-normal">Do big things with SPEC, the responsive bootstrap 4 admin template.</span>-->
            </h3>
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
              </ol>
            </nav>
          </div>
          <div class="row">
            <div class="col-md-4 stretch-card grid-margin">
              <div class="card bg-gradient-danger border-0 text-white p-3">
                <div class="card-body">
                  <div class="d-flex align-items-start">
                    <i class="mdi mdi-note mdi-48px"></i>
                    <div class="ml-4">
                      <h3 class="mb-2" id="subject name">Subject Name</h3>
                      <h4 class="mb-0" id="sub name">2</h4>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4 stretch-card grid-margin">
              <div class="card bg-gradient-info border-0 text-white p-3">
                <div class="card-body">
                  <div class="d-flex align-items-start">
                    <i class="mdi mdi-cards-outline mdi-48px"></i>
                    <div class="ml-4">
                      <h3 class="mb-2" id="balance leave">Balance Leave</h3>
                      <h4 class="mb-0">0</h4>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4 stretch-card grid-margin">
              <div class="card bg-gradient-success border-0 text-white p-3">
                <div class="card-body">
                  <div class="d-flex align-items-start">
                    <i class="mdi mdi-chart-line mdi-48px"></i>
                    <div class="ml-4">
                      <h3 class="mb-2" id="total leave">Total Leave</h3>
                        <h4 class="mb-0" id=""> 10+ </h4>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-4 d-flex align-items-stretch">
              <div class="row flex-grow-1 w-100">
                <div class="col-12 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body d-flex flex-column justify-content-center">
                      <div class="d-flex mb-3 align-items-center">
                          <h3 class="mb-0" id="assignments">10+ </h3>
                        <span class="ml-auto">Assignments </span>
                      </div>
                      <div class="progress progress-sm">
                        <div class="progress-bar bg-gradient-danger" role="progressbar" aria-valuenow="35" style="width: 20%" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
<!--                    <p class="mb-0 mt-3">42% higher than last month</p>-->
                    </div>
                  </div>
                </div>
                <div class="col-12 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body d-flex flex-column justify-content-center">
                      <div class="d-flex mb-3 align-items-center">
                        <h3 class="mb-0" id="attendance"> 70%</h3>
                        <span class="ml-auto">Attendance</span>
                      </div>
                      <div class="progress progress-sm">
                        <div class="progress-bar bg-gradient-info" role="progressbar" aria-valuenow="76" style="width:70%" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
<!--                      <p class="mb-0 mt-3">76% higher than last month</p>-->
                    </div>
                  </div>
                </div>
                <div class="col-12 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body d-flex flex-column justify-content-center">
                      <div class="d-flex mb-3 align-items-center">
                        <h3 class="mb-0" id="matirials">25+</h3>
                        <span class="ml-auto">Total Material</span>
                      </div>
                      <div class="progress progress-sm">
                        <div class="progress-bar bg-gradient-success" role="progressbar" aria-valuenow="76" id="progress"style="width: 25%" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
<!--                      <p class="mb-0 mt-3">76% higher than last month</p>-->
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-8 d-flex grid-margin stretch-card">
              <div class="card">
                <div class="card-body d-flex flex-column">
                  <div class="d-block d-lg-flex justify-content-between">
                    <h4 class="card-title" id="graph">Graph for Attendance</h4>                    
                    <ul class="nav nav-pills nav-pills-primary border-bottom-0">
                      <li class="nav-item">
                        <a class="nav-link" href="#">Month</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#">Week</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" href="#">All Time</a>
                      </li>
                    </ul>
                  </div>
                  <canvas id="earning-chart" class="mt-auto"></canvas>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-8 d-flex align-items-stretch">
              <div class="row flex-grow-1 w-100">
                <div class="col-12 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Acadmic Calander</h4>
                      <div id="calendar" class="full-calendar"></div>
              
                    </div>
                  </div>
                </div>

                <div class="col-12 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title clearfix" id="event">All Events
                        <span class="float-right text-primary text-small">
                          view all
                        </span>
                      </h4>
                      <div class="d-flex align-items-start border-bottom py-4">
                        <div class="form-check my-0">
                        </div>
                        <div class="flex-grow-1" id="event name">
                          <h6>
                            Python workshop
                          </h6>
                          <p class="text-muted mb-0" id="event date">Due on 12 am 27 Jun, 2018</p>
                        </div>
                        <div class="ml-auto">
                          <label class="badge badge-gradient-danger" id="register">Click to Register</label>
                        </div>
                      </div>
                      <div class="d-flex align-items-start border-bottom py-4">
                        <div class="form-check my-0">
                        </div>
                        <div class="flex-grow-1">
                          <h6>
                            Artificial Intelligence Seminar
                          </h6>
                          <p class="text-muted mb-0">Due on 6 am 28 Jun, 2018</p>
                        </div>
                        <div class="ml-auto">
                          <label class="badge badge-gradient-warning">Click to Register</label>
                        </div>
                      </div>
                      <div class="d-flex align-items-start border-bottom py-4">
                        <div class="form-check my-0">
                        </div>
                        <div class="flex-grow-1">
                          <h6>
                            Plan project release date
                          </h6>
                          <p class="text-muted mb-0">Due 0n 5 pm 29 Jun, 2018</p>
                        </div>
                        <div class="ml-auto">
                          <label class="badge badge-gradient-danger">Click to Register</label>
                        </div>
                      </div>
                      <div class="d-flex align-items-start border-bottom py-4">
                        <div class="form-check my-0">
                        </div>
                        <div class="flex-grow-1">
                          <h6>
                            Review the new app
                          </h6>
                          <p class="text-muted mb-0">Due 0n 3 pm 25 Jun, 2018</p>
                        </div>
                        <div class="ml-auto">
                          <label class="badge badge-gradient-info">Click to Register</label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4 d-flex align-items-stretch">
              <div class="row flex-grow-1 w-100">
                <div class="col-12 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body">
                      <div class="d-lg-flex align-items-center text-center text-lg-left">
                        <img src="images/faces/face16.jpg" class="img-lg rounded-circle mr-lg-4 mb-3 mb-lg-0" alt="imae"/>
                        <div>
                          <p class="text-small mb-2">YOUR PROFILE</p>
                          <h5>Pro. Mahesh Shah</h5>
                          <p class="font-weight-light mb-0">Assistent Professor</p>
                        </div>
                      </div>
                      <div class="mt-4 d-flex">
                        <div class="text-center border-right flex-grow-1 py-3">
                          <i class="mdi mdi-chart-bar text-danger icon-md"></i>
                        </div>
                        <div class="text-center flex-grow-1 py-3">
                          <i class="mdi mdi-comment-text-outline text-info icon-md"></i>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-12 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">My Activity</h4>
                      <p class="text-muted" id="activity date">27 Jul 2018</p>
                      <ul class="gradient-bullet-list">
                        <li>
                          <p>New Dashboard
                            <span class="float-right text-muted">11 pm</span>
                          </p>
                          <p class="text-small text-muted mb-0">Design</p>
                        </li>
                        <li>
                          <p>App Review
                            <span class="float-right text-muted">05 pm</span>
                          </p>
                          <p class="text-small text-muted mb-0">Testing</p>
                        </li>
                        <li>
                          <p>Blog Editing
                            <span class="float-right text-muted">06 pm</span>
                          </p>
                          <p class="text-small text-muted mb-0">Research</p>
                        </li>
                        <li>
                          <p>New Estimate
                            <span class="float-right text-muted">10 am</span>
                          </p>
                          <p class="text-small text-muted mb-0">Finance</p>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
                
                  <div class="col-12 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Notifications</h4>
                      <div class="d-flex py-4 border-bottom">
                        <div class="mr-3 bg-gradient-success icon-in-bg rounded-circle text-white">
                          <i class="mdi mdi-mouse-off"></i>
                        </div>
                        <div class="flex-grow-1">
                          <h6 class="mb-2">You got 10 views</h6>
                          <p class="text-muted mb-0">10 hrs ago</p>
                        </div>
                      </div>
                      <div class="d-flex py-4 border-bottom">
                        <div class="mr-3 bg-gradient-info icon-in-bg rounded-circle text-white">
                          <i class="mdi mdi-database"></i>
                        </div>
                        <div class="flex-grow-1">
                          <h6 class="mb-2">Boost your performance</h6>
                          <p class="text-muted mb-0">4 hrs ago</p>
                        </div>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2018 <a href="http://spec.edu.in" target="_blank">Sardar Patel College of Engineering</a>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Computer Department <i class="mdi mdi-heart text-danger"></i></span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
    <!--  Book Modal   -->
    <div class="modal fade text-dark" id="book-request">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-light">
                        <h5 class="modal-title" id="Title"><i class="fas fa-user-plus"></i> Book Request</h5>
                        <button class="close text-light" data-dismiss="modal"><span>&times;</span></button>
                    </div>
                    <div class="modal-body">
                    <form action="RequestNewBook.php" method="post">
		
                           <div class="form-group">
                               <label for="author">Author</label>
                               <input type="text" name="author" class="form-control">
                           </div>
                           <div class="form-group">
                               <label for="book_name">Book Name</label>
                               <input type="text" name="book_name" class="form-control">
                           </div>
                           <div class="form-group">
                               <label for="book_tpye">Book Type</label>
                               <input type="text" name="book_type" class="form-control">
                           </div>
                           <div class="form-group">
                               <label for="quantity">Quantity</label>
                               <input type="number" name="quantity" class="form-control">
                           </div>
                           <div class="form-group">
                               <label for="quantity">Price</label>
                               <input type="number" name="price" class="form-control">
                           </div>
                           <div class="form-group">
                               <label for="branch">Branch</label>
                               <input type="text" name="branch" class="form-control">
                           </div>
                           <div class="form-group">
                               <label for="issn_no">ISSN / ISBN No</label>
                               <input type="number" name="issn_no" class="form-control">
                           </div>
                           <div class="form-group">
                               <label for="edition">Edition</label>
                               <input type="text" name="edition" class="form-control">
                           </div>
                          
                                
                           <button class="btn btn-block btn-primary">Request</button>

	                </form>

                    

                    </div>
                </div>
            </div>
        </div>

        <!-- Leave form  -->
        <div class="modal fade text-dark" id="leave-form">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-light">
                        <h5 class="modal-title" id="Title">Leave Form</h5>
                        <button class="close text-light" data-dismiss="modal"><span>&times;</span></button>
                    </div>
                    <div class="modal-body">
                      <form action="php/StaffLeave.php" method="post">
                    <div class="form-group">
                      <label for="exampleInputUsername1">Faculty ID</label>
                      <input type="text" class="form-control" id="exampleInputUsername1" placeholder="Username" name="id">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">First Name</label>
                      <input type="text" class="form-control" id="fname" placeholder="fname" name="fname" value="" readonly/>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Last Name</label>
                      <input type="text" class="form-control" id="lname" placeholder="lname" name="lname" value="" readonly/>
                    </div>
                    <div class="form-group"
                      <label for="exampleInputUsername1">Department</label>
                      <input type="text" class="form-control" id="dept" placeholder=dept name="dept" value="" readonly/>
                    </div>
                    
                    <div class="">
                       <label>Leave Type</label>
                       <div class="row pl-3">
                           <div class="form-check mr-4">
                           <label class="form-check-label">
                               <input type="radio" name="type" class="form-check-input">
                               CL
                           </label>
                       </div>
                       <div class="form-check">
                           <label class="form-check-label">
                               <input type="radio" name="type" class="form-check-input">
                              SL
                           </label>
                       </div>
                       </div>
                   </div>
                              
                  
                          <div class="form-group">
                      <label for="exampleInputUsername1">Start Date</label>
                      <input type="text" class="form-control" id="sdate" placeholder="sdate" name="sdate" required="" />
                    </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">End Date</label>
                      <input type="text" class="form-control" id="sdate" placeholder="edate" name="edate" required="" />
                    </div>
                    <div class="form-group">
                      <label for="exampleTextarea1">Reason</label>
                      <textarea class="form-control" id="exampleTextarea1" rows="4" placeholder="Remark" name="reason" required=""></textarea>
                    </div>
                    <label for="exampleInputUsername1">Load Pass</label>
                      <input type="text" class="form-control" id="lp" placeholder="lp" name="lp" required="" />
                   <br> <button type="submit" name="submit" class="btn btn-gradient-primary mr-2">Submit</button> 
                    <button type="reset" class="btn btn-light">Reset</button>
                  </form>

                    </div>
                </div>
            </div>
        </div>

<!--         Material Upload-->

<div class="modal fade text-dark" id="Material-Upload">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-light">
                        <h5 class="modal-title" id="Title">Material Upload</h5>
                        <button class="close text-light" data-dismiss="modal"><span>&times;</span></button>
                    </div>
                    <div class="modal-body">
                      <form>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Faculty ID</label>
                      <input type="text" class="form-control" id="exampleInputUsername1" placeholder="Username" >
                    </div>
                    <div class="form-group">
                    <label>Semester</label>
                    <select class="js-example-basic-single" style="width:100%">
                      <option value="1">1st sem</option>
                      <option value="2">2nd sem</option>
                      <option value="3">3rd sem</option>
                      <option value="4">4th sem</option>
                      <option value="5">5th sem</option>
                      <option value="6">6th sem</option>
                      <option value="7">7th sem</option>
                      <option value="8">8th sem</option>
                    </select>
                  </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Type</label>
                      <input type="text" class="form-control" id="lname" placeholder="lname" />
                    </div>
<!--
                    <div class="card-body">
                  <h4 class="card-title">Upload File</h4>
                    
                  <input type="file" class="dropify" data-max-file-size="30kb" />
                </div>
-->
                          <div class="card">
                <div class="card-body">
                    <label for="name">Upload File</label>
<!--                  <h4 class="card-title">Upload File</h4>-->
                  <input type="file" class="dropify" data-default-file="images/file-icons/dropify-icon-small.html" />
                </div>
              </div>
            <br> <button type="submit" class="btn btn-gradient-primary mr-2">Submit</button> 
                    <button type="reset" class="btn btn-light">reset</button>
                          
                 </div>
                </div>
            </div>
        </div>

<!--                 Assignments Uload-->
                          
        <div class="modal fade text-dark" id="Assignment-Upload">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-light">
                        <h5 class="modal-title" id="Title">Assignment Upload</h5>
                        <button class="close text-light" data-dismiss="modal"><span>&times;</span></button>
                    </div>
                    <div class="modal-body">
                      <form>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Faculty ID</label>
                      <input type="text" class="form-control" id="exampleInputUsername1" placeholder="Username" >
                    </div>
                    <div class="form-group">
                    <label>Semester</label>
                    <select class="js-example-basic-single" style="width:100%">
                      <option value="1">1st sem</option>
                      <option value="2">2nd sem</option>
                      <option value="3">3rd sem</option>
                      <option value="4">4th sem</option>
                      <option value="5">5th sem</option>
                      <option value="6">6th sem</option>
                      <option value="7">7th sem</option>
                      <option value="8">8th sem</option>
                    </select>
                  </div>
                    <div class="form-group">
                      <label for="exampleInputUsername1">Subject</label>
                      <input type="text" class="form-control" id="lname" placeholder="Subject name" />
                    </div>
                          <div class="form-group">
                      <label for="exampleInputUsername1">Start Date</label>
                      <input type="text" class="form-control" id="lname" placeholder="Subject name" />
                    </div>
                          <div class="form-group">
                      <label for="exampleInputUsername1">End Date</label>
                      <input type="text" class="form-control" id="lname" placeholder="Subject name" />
                          </div>
<!--
                    <div class="card-body">
                  <h4 class="card-title">Upload File</h4>
                    
                  <input type="file" class="dropify" data-max-file-size="30kb" />
                </div>
-->
                          <div class="card">
                <div class="card-body">
                    <label for="name">Upload File</label>
<!--                  <h4 class="card-title">Upload File</h4>-->
                  <input type="file" class="dropify" data-default-file="images/file-icons/dropify-icon-small.html" />
                </div>
              </div>
                <br>
                <div class="form-group">
                      <label for="exampleInputUsername1">Remark</label>
                      <input type="text" class="form-control" id="lname" placeholder="Subject name" />
                    </div>
                          
                          <br> <button type="submit" class="btn btn-gradient-primary mr-2">Submit</button> 
                    <button type="reset" class="btn btn-light">Reset</button>
             </div>
                </div>
            </div>
        </div>
            
                    

  <!-- plugins:js -->
  <script src="vendors/js/vendor.bundle.base.js"></script>
  <script src="vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/misc.js"></script>
  <script src="js/settings.js"></script>
  <script src="js/todolist.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="js/dashboard.js"></script>
  <script src="js/calendar.js"></script>
    <script src="js/chart.js"></script>
  <!-- End custom js for this page-->
</body>


<!-- Mirrored from www.urbanui.com/gleam/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 16 Jul 2018 22:36:52 GMT -->
</html>
